<?php

session_start();
$_SESSION['username'] = $_POST['username'];


include dirname(__FILE__).'/src/adLDAP.php';
//if (isset ($_POST["username"], $_POST["password"])) {
$name = $_POST['username'];
$adldap = new adLDAP();
$adldap->user()->authenticate($_POST['username'], $_POST['password']);
  if ($userinfo = $adldap->user()->inGroup($_POST['username'], "WebApp")) {
  //if ($userinfo = $adldap->user()->inGroup($_POST["username"], "Remote Desktop Users")) {
  //echo 'both'; 
  $_SESSION['auth'] = TRUE;
  header('Location: system.php');
} else {
  $_SESSION['auth'] = FALSE;
  header('Location: error.php');

}

?>
