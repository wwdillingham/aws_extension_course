<?php

session_start();
echo $_SESSION['auth'];
include('header.php');
?>

<html>
<br><br><br>
<body>
<fieldset>
    <legend>User authentication:</legend>
<br>
    <p>Authentication has failed. Please check if:</p>
    <ul>
     <li><p>User exists and password is correct</p></li>
     <li><p>User is a member of WebApp group</p></li>
    </ul>
<br>
<input type="button" onclick="location.href='/app/index.php';" value="Back to Login" />
</body>
</html>
