<?php
session_start();
if ($_SESSION['auth'] ) {
include('header.php');


?>

<br><br><br>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo $_SESSION['username'];?> 's Workspace</title>
 </head>
 <body>
    <p>Welcome to <?php echo $_SESSION['username']?> workspace</p>
    <br>
    <a href="report.php">Customer List</a>
    &#124;
    <a href="logout.php">Logout</a>

  </body>

<?php } else {

header('Location: index.php');

}

?>
