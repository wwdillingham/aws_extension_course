<?php
session_start();
if ($_SESSION['auth'] ) {

$servername = "labdninstance-cluster.cluster-cwbkxqgerct7.us-east-1.rds.amazonaws.com";
//$servername = "labdninstance2.cwbkxqgerct7.us-east-1.rds.amazonaws.com";
$username = "master";
$password = "password";
$dbname = "labdb";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully";
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
} else {

header('Location: index.php');
}
?> 
