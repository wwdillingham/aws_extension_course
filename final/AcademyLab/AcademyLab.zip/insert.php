<?php
session_start();
include('dbconn.php');

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];

//echo $_POST['firstname'];
//echo $_REQUEST['lastname'];
//echo $_REQUEST['email'];

echo $firstname;
echo $lastname;
echo $email;


try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "INSERT INTO MyGuests (firstname, lastname, email)
    VALUES ('$firstname', '$lastname', '$email')";
    // use exec() because no results are returned
    $conn->exec($sql);
    echo "New record created successfully";
    header('Location: system.php');
     }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;
//header('Location: system.php');

?> 
