<?php
session_start();
if ($_SESSION['auth'] ) {
include('header.php');
include('dbconn.php');


?>

<br><br><br>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo $_SESSION['username'];?> 's Workspace</title>
 </head>
 <body>
    <p>Welcome to <?php echo $_SESSION['username']?> workspace</p>
    <br>
    <a href="report.php">Customer List</a>
    &#124;
    <a href="logout.php">Logout</a>
    <form action="insert.php" method="post">
       <br><br><a>First Name</a><br><input type="text" name="firstname"> 
       <br><br><a>Last Name</a><br><input type="text" name="lastname">
       <br><br><a>email</a><br><input type="text" name="email"> 
       <br><br><input type="submit" value="Submit">
    </form>

  </body>

<?php } else {

header('Location: index.php');

}

?>
