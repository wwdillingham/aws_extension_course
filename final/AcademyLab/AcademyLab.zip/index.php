<?php

session_start();
include('header.php');

?>
<html lang="en-us">
    
    <head>
        
        <!-- Basics -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
        <title>AWS Academy</title>

        <!-- CSS, you can upload this to S3, but must ensure that the object metadata is text/css -->
        <link href="sample.css" rel="stylesheet">
        
        <!-- Import web fonts using the link tag instead of CSS @import -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,900" rel="stylesheet">
        
        <!-- Icons from http://fontawesome.io/ -->
        <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
                
    </head>

    <body>
        <header id="main-header">
            <div class="container">
                <h1>AWS Academy</h1>
                <p>This will serve static pages</p>
            </div>
        </header>
        
        <section id="summary">
            <div class="container">
                <h2>User Login</h2>
				 <form action="test.php" method="post">
					<fieldset>
							First name:<br>
							<input type="text" name="username"><br>
							Password:<br>
							<input type="password" name="password"><br><br>
							<input type="submit" value="Submit">
						</fieldset>
					</form> 
            </div>
        </section>
        
        
        
        <!-- List Section -->
        <section id="list">
            <div class="container">
                <header class="body-header">
                    <h2>Aliquam erat volutpat.</h2>
                    <p>Sed adipiscing ornare risus. Morbi est est, blandit sit amet, sagittis vel, euismod vel, velit. Pellentesque egestas sem.</p>
                </header>
                <article>
                    <div class="list-row cf">
                        <div class="list-item">
                            <i class="fa fa-bullhorn fa-2x"></i>
                            <h3>Aenean erat volutpat</h3>
                            <p>Pellentesque odio nisi, euismod in, pharetra a, ultricies in, diam.</p>
                        </div>
                        <div class="list-item">
                            <i class="fa fa-code-fork fa-2x"></i>
                            <h3>Nam nulla quam</h3>
                            <p>Donec consectetuer ligula vulputate sem tristique cursus.</p>
                        </div>
                    </div>
                    <div class="list-row cf">
                        <div class="list-item">
                            <i class="fa fa-bolt fa-2x"></i>
                            <h3>Donec quam lectus</h3>
                            <p>Donec consectetuer ligula vulputate sem tristique cursus.</p>
                        </div>
                        <div class="list-item">
                            <i class="fa fa-folder-open fa-2x"></i>
                            <h3>Suspendisse commodo</h3>
                            <p>Morbi est est, blandit sit amet, sagittis vel, euismod vel, velit.</p>
                        </div>
                    </div>
                    <div class="list-row cf">
                        <div class="list-item">
                            <i class="fa fa-users fa-2x"></i>
                            <h3>Quisque volutpat mattis</h3>
                            <p>Integer vitae libero ac risus egestas placerat, elementum vulputate.</p>
                        </div>
                        <div class="list-item" id="last-item">
                            <i class="fa fa-wrench fa-2x"></i>
                            <h3>Lorem ipsum dolor</h3>
                            <p>Pellentesque odio nisi, euismod in, pharetra a, ultricies in, diam.</p>
                        </div>
                    </div>
                </article>
            </div>
        </section>
        
        
        <!-- Footer -->
        <footer>
            <div class="container">                    
                <div id="footer-text" class="small">
                <p>&copy; Sample Site Provided by AWS Academy</a></p>
                </div>
            </div>
        </footer>
        
    </body>

</html>
