<html lang="en-us">
    
    <head>
        
        <!-- Basics -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
        <title>AWS Academy</title>

        <!-- CSS, you can upload this to S3, but must ensure that the object metadata is text/css -->
        <link href="sample.css" rel="stylesheet">
        
        <!-- Import web fonts using the link tag instead of CSS @import -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,900" rel="stylesheet">
        
        <!-- Icons from http://fontawesome.io/ -->
        <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
                
    </head>

   <body>
	<section id="container 1">
            <div class="container">
				<!-- Move to your S3 bucket -->
                <img src="images/AWS.png"/>
            </div>
        </section>

   </body>
</html>
